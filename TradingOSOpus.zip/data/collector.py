import pandas as pd
import numpy as np

def get_mock_data():
    dates=pd.date_range(end=pd.Timestamp.today(),periods=200)
    price=np.cumsum(np.random.randn(200))+1000
    return pd.DataFrame({'date':dates,'close':price})
