import pandas as pd

def add_sma(df, n=20):
    df['sma']=df['close'].rolling(n).mean()
    return df
