# Vietnam AI Trading System (Production v2)
Full pipeline: data → features → ML/DL → strategies → backtest
Run: uvicorn api.main:app --reload
