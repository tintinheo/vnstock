from xgboost import XGBClassifier
import numpy as np

class Model:
    def __init__(self): self.model=XGBClassifier()
    def train(self,X,y): self.model.fit(X,y)
    def predict(self,X): return self.model.predict(X)
