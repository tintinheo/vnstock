from fastapi import FastAPI
from strategies.engine import run_strategy
app=FastAPI()

@app.get('/')
def root(): return {'status':'running'}

@app.get('/signal')
def signal(): return run_strategy()
