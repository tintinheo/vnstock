from data.collector import get_mock_data
from data.features import add_sma

def run_strategy():
    df=get_mock_data()
    df=add_sma(df)
    last=df.iloc[-1]
    if last['close']>last['sma']: return {'signal':'BUY'}
    return {'signal':'SELL'}
