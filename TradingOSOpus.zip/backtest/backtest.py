from strategies.engine import run_strategy

def run():
    return {'result':'backtest done'}
