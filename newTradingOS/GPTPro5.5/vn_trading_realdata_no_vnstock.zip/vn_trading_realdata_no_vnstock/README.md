# Vietnam Trading Real Data Scanner, No vnstock

This package is a Windows-friendly Python/Streamlit app for scanning Vietnam stock market data **without using vnstock**.

## What this version does

1. Fetches realtime/near-realtime snapshots directly from SSI iBoard-style endpoints, no `vnstock` dependency.
2. Scans realtime data for liquidity, momentum and risk alerts.
3. Allows upload of real historical OHLCV CSV from your licensed/public source for full indicators, market regime, sector rotation, stock scoring, signals and backtesting.
4. Includes an optional synthetic sample generator only for offline UI testing.

## Run on Windows 11

Double-click:

```text
run_windows.bat
```

Or manually:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## Real historical CSV schema

For full scoring/backtesting, upload CSV with:

```text
symbol,date,open,high,low,close,volume,value,exchange,sector
```

## Important

The direct SSI adapter is a lightweight public-snapshot adapter, not an official SDK. Validate terms of use, stability and rate limits before production use. For production, prefer licensed providers such as Vietstock DataFeed, FiinPro-X/FiinTrade, SSI Fast Connect API, or broker-provided exports.
